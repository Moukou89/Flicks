package com.codepath.flicks;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.codepath.flicks.models.Movie;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {
 // constants
 // The base URL for the API
  public final static String API_BASE_URL="htpps//api.themoviedb.org/3";
   // the parameter name for the API key
  public final static  String API_KEY_PARAM ="api_key";
  public final  static  String API_KEY = "api_key";
    // Tag for logging from this activity
    public final static String TAG = "TheMovieListActivity";
    // Instant fields
    AsyncHttpClient client;
    // The list of current playing movies
    ArrayList<Movie> movies;
    //Recycle view
    RecyclerView rvMovies;
    //The adapter wired to the recycler view
    MovieAdapter adapter;
    // image config
    Config config;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //initialize the client
        client = new AsyncHttpClient();
        //initialize the list of movies
        movies = new ArrayList<>();
        //initialize the adapter - movie array cannot be reinitialized after this point
        adapter = new MovieAdapter(movies);
        // resolve the recycler and connect a layout manager and the adapter
        rvMovies = (RecyclerView) findViewById(R.id.rvMovies);
        rvMovies.setLayoutManager(new LinearLayoutManager(this));
        rvMovies.setAdapter(adapter);

        /* get the configuration on app creation */
        getConfiguration();

    }
    public void getNowPlaying(){
        // Create the URL
        String url = API_BASE_URL +"/movie/now_playing";
        // set the request parameters
        RequestParams params = new RequestParams();
        params.put( API_KEY_PARAM, getString(R.string.api_key)); // API KEYS ALWAYS REQUIRED
        // execute a GET  request expecting a Json object response
        client.get(url, params, new JsonHttpResponseHandler(){
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                // load the results into movies List
                try{
                    JSONArray results = response.getJSONArray("results");
                    // iterate through result set and create Move object
                    for  (int i = 0; i< results.length();i++){
                        Movie  movie = new Movie(results.getJSONObject(i));
                        movies.add(movie);
                        // notify adapter that a row was added
                        adapter.notifyItemInserted(movies.size()-1);
                    }
                    Log.i(TAG, String.format("Loaded %s movies",results.length()));

                }catch (JSONException e)
                {
                logError("Failed to parse now_playing movies",e, true);
                }
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                logError("Failed to get data from now_playing endpoint", throwable, true);
            }

        });
    }


        // get the list of current movie playing from the API

    // Get the configuration from client
    public void getConfiguration(){
        // Create the URL
        String url = API_BASE_URL +"/configuration";
        // set the request parameters
        RequestParams params = new RequestParams();
        params.put(API_KEY_PARAM, getString(R.string.api_key)); // API KEYS ALWAYS REQUIRED
        // execute a GET  request expecting a Json object response
        client.get(url, params, new JsonHttpResponseHandler(){
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                try {
                    config = new Config(response);

                    Log.i(TAG,
                            String.format("Loaded configuration with imageBaseUrl %s and posterSize %s, imageBaseUrl, posterSize" ));
                    config.getImageBaseUrl();
                    config.getPosterSize();
                    // pass config to a adapter
                    adapter.setConfig(config );
                   //get the now_playing movie List
                    getNowPlaying();
                } catch (JSONException e) {
                    logError("Failed parsing configuration", e,true);
                }

            }
            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                logError("Failed getting configuration", throwable, true );
            }
        });
    }
    // Handle errors, log and alert for user

    private void logError(String message, Throwable error, boolean alertuser){
     // Always log error
        Log.e(TAG, message, error);
        //Alert the user to avoid silents errors
        if (alertuser){
            // Show a long toast with the error message
            Toast.makeText(getApplicationContext(), message,Toast.LENGTH_LONG).show();

        }
    }
}
